@echo off
setlocal

REM ============================================================
REM  Stops and removes the AttendanceAPILogger Windows Service.
REM  MUST be run as Administrator.
REM ============================================================

set SERVICE_NAME=AttendanceAPILogger
set NSSM_PATH=%~dp0nssm.exe

if not exist "%NSSM_PATH%" (
    echo.
    echo ERROR: nssm.exe not found in this folder.
    echo It's needed to remove the service cleanly.
    echo.
    pause
    exit /b 1
)

echo Stopping service "%SERVICE_NAME%"...
"%NSSM_PATH%" stop %SERVICE_NAME%

echo Removing service "%SERVICE_NAME%"...
"%NSSM_PATH%" remove %SERVICE_NAME% confirm

echo.
echo Done. The service has been removed. The program files themselves
echo (AttendanceLogger.exe, config.json, logs.json) were not touched.
echo.
pause
