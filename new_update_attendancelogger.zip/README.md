# Attendance API Logger — Portable Build

A standalone Windows program that:
- Receives POST requests from attendance/biometric devices or software
- Logs every request (success/failed) to a dashboard at `http://localhost:<port>/`
- Writes successful punches into any SQL Server database, deduplicated on
  `EMP_CODE + PUNCH_DATETIME + TERMINAL_SN`

No Node.js installation is required on the target machine — everything is
bundled into one `.exe`.

## Building the .exe (do this once, on a machine with internet access)

```bash
npm install
npm run build
```

This produces `dist/AttendanceLogger.exe`. `pkg` needs internet access the
first time it runs, to download the prebuilt Node.js binary it bundles —
after that, the build is fully offline.

## What to ship to a customer/target machine

Copy these into one folder on the target machine:

```
AttendanceLogger/
├── AttendanceLogger.exe
├── config.example.json      (rename to config.json, or let the exe create it)
├── install-service.bat
├── uninstall-service.bat
└── nssm.exe                 (you add this — see below)
```

## First run on the target machine

1. Double-click `AttendanceLogger.exe` once. It will exit immediately and
   create `config.json` next to itself (using the built-in defaults if
   `config.example.json` wasn't provided).
2. Edit `config.json`:
   - `mssql` — point at that machine's SQL Server (works for a local
     instance, a different server on the network, or Azure SQL — anything
     reachable over `server:port`).
   - `server.port` / `server.receivePath` — where the app listens. Change
     these if port 3000 is already in use, or to match what the
     attendance software expects.
   - `server.apiKey` — optional. Set this to require a shared secret
     (`x-api-key` header) on incoming requests; leave blank to accept any
     request, same as the original behavior.
3. Test it by double-clicking `AttendanceLogger.exe` again — confirm the
   dashboard loads at `http://localhost:<port>/` and a test payload
   reaches SQL Server, then close that window.
4. **Now install it as an auto-start service** — see below. This is the
   recommended way to actually run it day-to-day, instead of leaving a
   console window open.
5. In your attendance device/software, set the "API URL" field to:
   ```
   http://<this-machine's-IP>:<port><receivePath>
   ```
6. Open `http://localhost:<port>/` on that machine to see the dashboard.

## Installing as an auto-start Windows Service (recommended)

This makes the program start automatically on boot, run invisibly (no
console window), and restart itself if it ever crashes. It uses
[NSSM](https://nssm.cc/) — a small, well-known tool for running any
`.exe` as a proper Windows Service, so the "no Node.js needed" promise
still holds.

**One-time setup, per machine:**

1. Download NSSM from https://nssm.cc/download.
2. Inside the zip, find `win64\nssm.exe` (or `win32\nssm.exe` on an old
   32-bit machine) and copy just that file into the same folder as
   `AttendanceLogger.exe`.
3. Make sure `config.json` already exists and is filled in (step 1–3
   above) — the installer checks for this and refuses to run otherwise.
4. Right-click `install-service.bat` → **Run as administrator**.

That's it. The service is named `AttendanceAPILogger`. It will now:
- Start automatically every time the machine boots, before any user logs in
- Run with no visible window
- Restart itself automatically if it crashes
- Write its console output to `service-logs\service-out.log` and
  `service-logs\service-err.log` (auto-rotated at 10 MB)

**Checking on it:**
- `sc query AttendanceAPILogger` from a command prompt, or
- Open `services.msc` and look for "Attendance API Logger"

**Changing `config.json` after the service is installed:** stop the
service first (`sc stop AttendanceAPILogger` or via `services.msc`), edit
the file, then start it again (`sc start AttendanceAPILogger`).

**Removing the service:** right-click `uninstall-service.bat` → **Run as
administrator**. This only removes the service registration — it does not
delete `AttendanceLogger.exe`, `config.json`, or `logs.json`.

## Database table

The app expects a table `dbo.PunchLogs` in the configured database, with
columns matching the fields in the payload (`COMPANY_NAME`, `EMP_CODE`,
`FIRST_NAME`, ... `MASK_FLAG`). If a fresh database is being used, create
that table first — ask me for the `CREATE TABLE` script if needed.
