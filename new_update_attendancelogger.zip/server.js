/**
 * Attendance API Logger — portable build
 * ---------------------------------------
 * On first run this creates a config.json next to the program.
 * Edit that file with your SQL Server details, API port/path, and
 * (optionally) an API key, then restart.
 *
 * Point your device/software's "API URL" field at:
 *     http://YOUR_SERVER:PORT<receivePath>
 *
 * Every POST it sends is recorded (success or failed) along with the
 * exact payload, so you can inspect it in the dashboard at:
 *     http://YOUR_SERVER:PORT/
 *
 * Every successful POST is also saved into SQL Server (dbo.PunchLogs),
 * with duplicates skipped based on EMP_CODE + PUNCH_DATETIME + TERMINAL_SN.
 */

const express = require("express");
const fs = require("fs");
const path = require("path");
const { sql, getPool, parsePunchDateTime } = require("./db");
const { loadConfig, baseDir, CONFIG_PATH } = require("./config");

const config = loadConfig();

const app = express();
const PORT = config.server.port;
const RECEIVE_PATH = config.server.receivePath;
const API_KEY = config.server.apiKey;
const MAX_LOGS = config.logging.maxLogs;

// Runtime data (logs.json) lives on real disk next to the program/config,
// NOT inside __dirname, which is a read-only virtual filesystem when
// this is packaged into a single .exe with pkg.
const LOG_FILE = path.join(baseDir, "logs.json");

// ---------- persistence helpers ----------
function loadLogs() {
  try {
    if (fs.existsSync(LOG_FILE)) {
      const raw = fs.readFileSync(LOG_FILE, "utf8");
      return raw ? JSON.parse(raw) : [];
    }
  } catch (err) {
    console.error("Could not read logs.json, starting fresh:", err.message);
  }
  return [];
}

function saveLogs(logs) {
  try {
    fs.writeFileSync(LOG_FILE, JSON.stringify(logs, null, 2));
  } catch (err) {
    console.error("Could not write logs.json:", err.message);
  }
}

let logs = loadLogs();

function addLog(entry) {
  logs.unshift(entry); // newest first
  if (logs.length > MAX_LOGS) logs = logs.slice(0, MAX_LOGS);
  saveLogs(logs);
}

// ---------- SQL Server save helper ----------
async function saveToDatabase(records) {
  const pool = await getPool();
  const list = Array.isArray(records) ? records : [records];

  for (const rec of list) {
    await pool.request()
      .input("COMPANY_NAME", sql.VarChar, rec.COMPANY_NAME || null)
      .input("EMP_CODE", sql.VarChar, rec.EMP_CODE || null)
      .input("FIRST_NAME", sql.VarChar, rec.FIRST_NAME || null)
      .input("LAST_NAME", sql.VarChar, rec.LAST_NAME || null)
      .input("DEPT_NAME", sql.VarChar, rec.DEPT_NAME || null)
      .input("POSITION_NAME", sql.VarChar, rec.POSITION_NAME || null)
      .input("PUNCH_DATETIME", sql.DateTime, parsePunchDateTime(rec.PUNCH_DATETIME))
      .input("PUNCH_TIME", sql.VarChar, rec.PUNCH_TIME || null)
      .input("PUNCH_STATE", sql.VarChar, rec.PUNCH_STATE || null)
      .input("VERIFY_TYPE", sql.VarChar, rec.VERIFY_TYPE || null)
      .input("WORK_CODE", sql.VarChar, rec.WORK_CODE || null)
      .input("GPS_LOCATION", sql.VarChar, rec.GPS_LOCATION || null)
      .input("LONGITUDE", sql.VarChar, rec.LONGITUDE || null)
      .input("LATITUDE", sql.VarChar, rec.LATITUDE || null)
      .input("AREA_NAME", sql.VarChar, rec.AREA_NAME || null)
      .input("TERMINAL_SN", sql.VarChar, rec.TERMINAL_SN || null)
      .input("TERMINAL_ALIAS", sql.VarChar, rec.TERMINAL_ALIAS || null)
      .input("UPLOAD_TIME", sql.DateTime, rec.UPLOAD_TIME ? new Date(rec.UPLOAD_TIME) : null)
      .input("TEMPERATURE", sql.VarChar, rec.TEMPERATURE || null)
      .input("MASK_FLAG", sql.VarChar, rec.MASK_FLAG || null)
      .query(`
        MERGE dbo.PunchLogs AS target
        USING (SELECT
            @EMP_CODE AS EMP_CODE,
            @PUNCH_DATETIME AS PUNCH_DATETIME,
            @TERMINAL_SN AS TERMINAL_SN
        ) AS source
        ON  target.EMP_CODE = source.EMP_CODE
        AND target.PUNCH_DATETIME = source.PUNCH_DATETIME
        AND ISNULL(target.TERMINAL_SN, '') = ISNULL(source.TERMINAL_SN, '')

        WHEN NOT MATCHED THEN
            INSERT (COMPANY_NAME, EMP_CODE, FIRST_NAME, LAST_NAME, DEPT_NAME, POSITION_NAME,
                    PUNCH_DATETIME, PUNCH_TIME, PUNCH_STATE, VERIFY_TYPE, WORK_CODE,
                    GPS_LOCATION, LONGITUDE, LATITUDE, AREA_NAME, TERMINAL_SN, TERMINAL_ALIAS,
                    UPLOAD_TIME, TEMPERATURE, MASK_FLAG)
            VALUES (@COMPANY_NAME, @EMP_CODE, @FIRST_NAME, @LAST_NAME, @DEPT_NAME, @POSITION_NAME,
                    @PUNCH_DATETIME, @PUNCH_TIME, @PUNCH_STATE, @VERIFY_TYPE, @WORK_CODE,
                    @GPS_LOCATION, @LONGITUDE, @LATITUDE, @AREA_NAME, @TERMINAL_SN, @TERMINAL_ALIAS,
                    @UPLOAD_TIME, @TEMPERATURE, @MASK_FLAG);
      `);
  }
}

// ---------- middleware ----------
app.use(
  express.json({
    limit: "5mb",
    // capture raw body text too, in case JSON parsing fails
    verify: (req, res, buf) => {
      req.rawBody = buf.toString("utf8");
    },
  })
);
app.use(express.urlencoded({ extended: true }));

// Allow the software to call this from anywhere (CORS)
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET,POST,DELETE,OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type, Authorization, x-api-key");
  if (req.method === "OPTIONS") return res.sendStatus(200);
  next();
});

app.use(express.static(path.join(__dirname, "public")));

// ---------- tolerate a trailing space in the configured API URL ----------
// Some software appends a stray space to the URL (shows up as "%20" or "+").
// Strip trailing whitespace/encoded-space from the path before routing.
app.use((req, res, next) => {
  req.url = req.url.replace(/(%20|\+|\s)+$/i, "");
  next();
});

// ---------- log every single request that hits this server, no matter what ----------
app.use((req, res, next) => {
  console.log(
    `[${new Date().toLocaleTimeString()}] ${req.method} ${req.originalUrl} ` +
      `from ${req.ip} | content-type: ${req.headers["content-type"] || "(none)"}`
  );
  next();
});

// ---------- optional API key check (only enforced if configured) ----------
function checkApiKey(req, res, next) {
  if (!API_KEY) return next(); // no key configured -> open, matches original behavior
  const provided = req.headers["x-api-key"] || req.headers["authorization"]?.replace(/^Bearer\s+/i, "");
  if (provided !== API_KEY) {
    return res.status(401).json({ success: false, message: "Invalid or missing API key" });
  }
  next();
}

// ---------- the endpoint your attendance software posts to ----------
app.post(RECEIVE_PATH, checkApiKey, async (req, res) => {
  const timestamp = new Date().toISOString();
  const body = req.body;
  const isEmpty =
    body === undefined ||
    body === null ||
    (typeof body === "object" && Object.keys(body).length === 0);

  const entry = {
    id: Date.now() + "-" + Math.random().toString(36).slice(2, 8),
    timestamp,
    status: isEmpty ? "failed" : "success",
    reason: isEmpty ? "Empty or unparsable body" : null,
    headers: req.headers,
    data: body,
  };

  addLog(entry);

  if (isEmpty) {
    return res.status(400).json({ success: false, message: "No data received" });
  }

  // Save to SQL Server — logged separately so a DB issue never blocks
  // the response to your attendance device, and still shows in logs.json
  try {
    await saveToDatabase(body);
  } catch (err) {
    console.error("DB insert failed:", err.message);
  }

  // Respond however your software expects. Plain success JSON is a safe default.
  return res.status(200).json({ success: true, message: "Data received", id: entry.id });
});

// Also accept GET on the same path, in case something pings it to test connectivity
app.get(RECEIVE_PATH, (req, res) => {
  res.json({ status: "ok", message: "Endpoint is up. Send a POST with JSON data." });
});

// ---------- JSON parse error handler (logs malformed requests as "failed") ----------
app.use((err, req, res, next) => {
  if (err.type === "entity.parse.failed") {
    const entry = {
      id: Date.now() + "-" + Math.random().toString(36).slice(2, 8),
      timestamp: new Date().toISOString(),
      status: "failed",
      reason: "Invalid JSON: " + err.message,
      headers: req.headers,
      data: req.rawBody || null,
    };
    addLog(entry);
    return res.status(400).json({ success: false, message: "Invalid JSON" });
  }
  console.error(err);
  res.status(500).json({ success: false, message: "Server error" });
});

// ---------- dashboard API ----------
app.get("/api/logs", (req, res) => {
  res.json(logs);
});

app.delete("/api/logs", (req, res) => {
  logs = [];
  saveLogs(logs);
  res.json({ success: true });
});

// send a sample payload to yourself, to try the dashboard out
app.post("/api/test", async (req, res) => {
  const sample = [
    {
      COMPANY_NAME: "COMPANY",
      EMP_CODE: "1234",
      FIRST_NAME: "XYZ",
      LAST_NAME: "",
      DEPT_NAME: "Department",
      POSITION_NAME: "Position",
      PUNCH_DATETIME: new Date().toISOString().slice(0, 19).replace("T", " "),
      PUNCH_TIME: new Date().toTimeString().slice(0, 8),
      PUNCH_STATE: "Check In",
      VERIFY_TYPE: "Automatic",
      WORK_CODE: "",
      GPS_LOCATION: "",
      LONGITUDE: "",
      LATITUDE: "",
      AREA_NAME: "",
      TERMINAL_SN: "",
      TERMINAL_ALIAS: "",
      UPLOAD_TIME: new Date().toISOString(),
      TEMPERATURE: "",
      MASK_FLAG: "",
    },
  ];

  // Run this through the SAME path a real device punch takes - including
  // the actual SQL insert - so "Send test payload" genuinely proves the
  // whole pipeline (server + DB) works, not just the dashboard/logs.json.
  let dbError = null;
  try {
    await saveToDatabase(sample);
  } catch (err) {
    dbError = err.message;
    console.error("Test payload DB insert failed:", err.message);
  }

  addLog({
    id: Date.now() + "-test",
    timestamp: new Date().toISOString(),
    status: dbError ? "failed" : "success",
    reason: dbError ? "DB insert failed: " + dbError : null,
    headers: { "content-type": "application/json", "x-source": "manual test" },
    data: sample,
  });
  res.json({ success: !dbError, dbError });
});

app.listen(PORT, () => {
  console.log(`Attendance API Logger running:`);
  console.log(`  Config file:    ${CONFIG_PATH}`);
  console.log(`  Dashboard:      http://localhost:${PORT}/`);
  console.log(`  Receiver URL:   http://localhost:${PORT}${RECEIVE_PATH}  <-- put this in "API URL"`);
  if (API_KEY) console.log(`  API key required: yes (send as  x-api-key: <key>  header)`);
});
