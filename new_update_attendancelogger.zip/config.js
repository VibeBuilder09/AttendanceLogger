const fs = require("fs");
const path = require("path");

/**
 * Where runtime data lives.
 * - When packaged with `pkg`, process.pkg is set and the code runs from a
 *   virtual read-only filesystem, so config/logs must live next to the
 *   .exe on real disk: path.dirname(process.execPath).
 * - When run normally with `node index.js`, that's just this folder.
 */
const baseDir = process.pkg ? path.dirname(process.execPath) : __dirname;
const CONFIG_PATH = path.join(baseDir, "config.json");

const DEFAULT_CONFIG = {
  server: {
    port: 3000,
    receivePath: "/api/receive",
    // If set, incoming requests must send header  x-api-key: <this value>
    // Leave blank to accept any request (matches original behavior).
    apiKey: ""
  },
  mssql: {
    user: "sa",
    password: "",
    server: "127.0.0.1",
    database: "endpoint_data",
    port: 1433,
    encrypt: false,
    trustServerCertificate: true,
    // Keep false unless you know you want UTC conversion on insert —
    // see note in original db.js about IST wall-clock timestamps.
    useUTC: false
  },
  logging: {
    maxLogs: 1000
  }
};

function ensureConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(DEFAULT_CONFIG, null, 2));
    console.log("No config.json found next to the program.");
    console.log(`Created a template at:\n  ${CONFIG_PATH}`);
    console.log("Edit it with your SQL Server details and API settings, then restart.");
    process.exit(0);
  }
}

function loadConfig() {
  ensureConfig();
  const raw = fs.readFileSync(CONFIG_PATH, "utf8");
  let cfg;
  try {
    cfg = JSON.parse(raw);
  } catch (err) {
    console.error(`config.json is not valid JSON: ${err.message}`);
    process.exit(1);
  }
  // Merge with defaults so upgrades that add new keys don't break old configs.
  return {
    server: { ...DEFAULT_CONFIG.server, ...cfg.server },
    mssql: { ...DEFAULT_CONFIG.mssql, ...cfg.mssql },
    logging: { ...DEFAULT_CONFIG.logging, ...cfg.logging }
  };
}

module.exports = { loadConfig, CONFIG_PATH, baseDir };
