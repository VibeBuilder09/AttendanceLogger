const sql = require("mssql");
const { loadConfig } = require("./config");

const config = loadConfig();

const dbConfig = {
  user: config.mssql.user,
  password: config.mssql.password,
  server: config.mssql.server,
  database: config.mssql.database,
  port: config.mssql.port,
  options: {
    encrypt: config.mssql.encrypt,
    trustServerCertificate: config.mssql.trustServerCertificate,
    // IMPORTANT: without this, the mssql/tedious driver converts every
    // Date object to UTC before sending it to SQL Server. If this
    // machine's OS/Node timezone is IST (UTC+5:30), that silently
    // subtracts 5:30 from every PUNCH_DATETIME on insert - which is
    // exactly the bug we're fixing here. Setting this to false tells
    // the driver to send the literal wall-clock numbers instead.
    useUTC: config.mssql.useUTC
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000
  }
};

let poolPromise;
function getPool() {
  if (!poolPromise) {
    poolPromise = new sql.ConnectionPool(dbConfig)
      .connect()
      .then(pool => {
        console.log(`Connected to SQL Server (${dbConfig.server}:${dbConfig.port}/${dbConfig.database})`);
        return pool;
      })
      .catch(err => {
        console.error("DB Connection Failed:", err.message);
        poolPromise = null;
        throw err;
      });
  }
  return poolPromise;
}

function parsePunchDateTime(str) {
  if (!str) return null;
  const [datePart, timePart] = str.split(" ");
  const [day, month, year] = datePart.split("-");
  return new Date(`${year}-${month}-${day}T${timePart}`);
}

module.exports = { sql, getPool, parsePunchDateTime };
