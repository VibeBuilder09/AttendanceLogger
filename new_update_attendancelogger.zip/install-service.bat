@echo off
setlocal

REM ============================================================
REM  Installs AttendanceLogger.exe as an auto-start Windows
REM  Service using NSSM (https://nssm.cc/).
REM
REM  MUST be run as Administrator (right-click > Run as administrator).
REM ============================================================

set SERVICE_NAME=AttendanceAPILogger
set EXE_PATH=%~dp0AttendanceLogger.exe
set NSSM_PATH=%~dp0nssm.exe
set LOG_DIR=%~dp0service-logs

echo Checking prerequisites...

if not exist "%NSSM_PATH%" (
    echo.
    echo ERROR: nssm.exe not found in this folder.
    echo Download it from https://nssm.cc/download, pull nssm.exe out of the
    echo win64 folder inside the zip, and place it right here next to
    echo AttendanceLogger.exe. Then run this script again.
    echo.
    pause
    exit /b 1
)

if not exist "%EXE_PATH%" (
    echo.
    echo ERROR: AttendanceLogger.exe not found in this folder.
    echo.
    pause
    exit /b 1
)

if not exist "%~dp0config.json" (
    echo.
    echo ERROR: config.json not found yet.
    echo Run AttendanceLogger.exe once manually first ^(double-click it^) so it
    echo can create config.json, edit that file with your SQL Server details,
    echo then run this installer again.
    echo.
    pause
    exit /b 1
)

if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

echo.
echo Installing service "%SERVICE_NAME%"...
"%NSSM_PATH%" install %SERVICE_NAME% "%EXE_PATH%"
"%NSSM_PATH%" set %SERVICE_NAME% AppDirectory "%~dp0"
"%NSSM_PATH%" set %SERVICE_NAME% Start SERVICE_AUTO_START
"%NSSM_PATH%" set %SERVICE_NAME% DisplayName "Attendance API Logger"
"%NSSM_PATH%" set %SERVICE_NAME% Description "Receives attendance punch data over HTTP and logs it to SQL Server."

REM Keep console output even though there's no visible window
"%NSSM_PATH%" set %SERVICE_NAME% AppStdout "%LOG_DIR%\service-out.log"
"%NSSM_PATH%" set %SERVICE_NAME% AppStderr "%LOG_DIR%\service-err.log"
"%NSSM_PATH%" set %SERVICE_NAME% AppRotateFiles 1
"%NSSM_PATH%" set %SERVICE_NAME% AppRotateBytes 10485760

REM Auto-restart if it ever crashes, with a small delay to avoid a crash loop
"%NSSM_PATH%" set %SERVICE_NAME% AppExit Default Restart
"%NSSM_PATH%" set %SERVICE_NAME% AppRestartDelay 5000

echo.
echo Starting service...
"%NSSM_PATH%" start %SERVICE_NAME%

echo.
echo ============================================================
echo  Done. "%SERVICE_NAME%" is installed and set to start
echo  automatically on boot, and will restart if it crashes.
echo.
echo  Check status:   sc query %SERVICE_NAME%
echo  Or open:        services.msc
echo  Logs:           %LOG_DIR%
echo ============================================================
echo.
pause
